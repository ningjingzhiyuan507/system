import logging
import os.path
import pandas as pd


def bp_process(path_read):
    table_name = '入院录.体格检查.血压'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    result = (
        df
        .query("部位 == '左上肢'")[['json_name', '收缩压', '舒张压']]
        .assign(
            收缩压=lambda df: pd.to_numeric(df['收缩压'], errors='coerce'),
            舒张压=lambda df: pd.to_numeric(df['舒张压'], errors='coerce'))
        .dropna()
    )

    logging.info(f"{table_name} 表预处理完成……")
    return result