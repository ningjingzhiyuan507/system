import logging
import os.path
import pandas as pd


def heart_aus_process(path_read):
    """心脏听诊"""
    table_name = '入院录.专科检查.心脏听诊'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    results = pd.pivot_table(
        df[['json_name', '杂音部位']],
        index='json_name',
        columns='杂音部位',
        aggfunc=lambda x: 1,  # 将值映射为 1
        fill_value=0
    ).add_prefix('心脏听诊_').reset_index()

    logging.info(f"{table_name} 表预处理完成……")
    return results


