import logging
import os
import pandas as pd

OPERATION = {
    '主动脉瓣置换术': "主动脉瓣.*(置入|植入|置换)",
    '二尖瓣成形术': "二尖瓣.*成形",
    '二尖瓣置换术': "二尖瓣.*(置入|植入|置换)",
    '三尖瓣成形术': "三尖瓣.*成形",
}


def operation_history_process(path_read):
    table_name = '入院录.既往史.手术外伤史'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    df = df.dropna(subset=['json_name', '手术名称'])

    results = []
    for _, row in df.iterrows():
        operations = row['手术名称'].split('@')
        for o in operations:
            results.append({
                'json_name': row['json_name'],
                '手术时间': row['手术日期'],
                '手术名称': o
            })
    results = pd.DataFrame(results)
    results['手术标准名'] = None
    for o in OPERATION:
        results.loc[results['手术名称'].str.contains(OPERATION[o]), '手术标准名'] = o

    results = results[['json_name', '手术标准名']].dropna()
    results = pd.pivot_table(
        results,
        index='json_name',
        columns='手术标准名',
        aggfunc=lambda x: 1,  # 将值映射为 1
        fill_value=0  # 缺失值填充为 0
    ).add_prefix('手术史_').reset_index()

    logging.info(f"{table_name} 表预处理完成……")
    return results


if __name__ == '__main__':
    path_read = '/Users/gxz/Desktop/PT/因果发现/data/raw'
    path_save = '/Users/gxz/Desktop/PT/因果发现/data/process'

    operation_history_process(path_read, path_save)