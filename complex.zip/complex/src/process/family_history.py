import logging
import os
import pandas as pd


FAMILY = [
    '冠心病', '糖尿病', '心肌病', '高血压'
]


def family_history_process(path_read):
    table_name = '入院录.其他信息.家族史'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv')).dropna()

    results = []
    for _, row in df.iterrows():
        for f in FAMILY:
            if f in row['value']:
                results.append({
                    'json_name': row['json_name'],
                    '家族史': f,
                })
    results = pd.DataFrame(results)
    results = pd.pivot_table(
        results,
        index='json_name',
        columns='家族史',
        aggfunc=lambda x: 1,  # 将值映射为 1
        fill_value=0  # 缺失值填充为 0
    ).add_prefix('家族史_').reset_index()

    logging.info(f"{table_name} 表预处理完成……")
    return results


if __name__ == '__main__':
    path_read = '/Users/gxz/Desktop/PT/因果发现/data/raw'
    path_save = '/Users/gxz/Desktop/PT/因果发现/data/process'

    family_history_process(path_read, path_save)



