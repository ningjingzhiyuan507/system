import logging
import os.path
import pandas as pd

DIAG = [
    '冠状动脉粥样硬化性心脏病', '非风湿性二尖瓣关闭不全', '非风湿性主动脉瓣关闭不全',
    '2型糖尿病', '高血压病3级（极高危）', '二尖瓣脱垂伴关闭不全',
    '非风湿性三尖瓣关闭不全', '升主动脉扩张'
]


def diag_admission_process(path_read):
    table_name = '住院信息.诊断信息.入院诊断'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv')).dropna()

    results = []
    for _, row in df.iterrows():
        diag_split = row['value'].split(',')
        for d in diag_split:
            if d in DIAG:
                results.append({
                    'json_name': row['json_name'],
                    '诊断': d
                })
    results = pd.DataFrame(results)
    results = pd.pivot_table(
        results,
        index='json_name',
        columns='诊断',
        aggfunc=lambda x: 1,  # 将值映射为 1
        fill_value=0  # 缺失值填充为 0
    ).add_prefix('入院诊断_').reset_index()

    logging.info(f"{table_name} 表预处理完成……")
    return results