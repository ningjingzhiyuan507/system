"""
对数据进行探查：查看变量分布
"""
# import sys
# sys.path.append('/code/AIDD')

import os
import pandas as pd
import json
import collections
import logging
import time

# todo: 针对化验，列出检验套餐、检验项目以进行标准化
# todo: 针对药嘱，列出药品名，规格以进行标准化

# key对应的值为list，里面嵌套dict。根据主要field统计频次
VAR_LIST_DICT = {
    '化验结果': ['类型', '详细类型', '项目'],
    '药嘱': ['药名', '规格'],
    ('住院信息', '手术信息'): ['手术'],
    ('入院录.基本信息', '症状'): ['症状名称'],
    ('入院录.既往史', '疾病史'): ['疾病名'],
    ('入院录.既往史', '药物史'): ['药物名称'],
    ('入院录.既往史', '传染病史'): ['传染病名'],
    ('入院录.既往史', '手术外伤史'): ['手术名称'],
    ('入院录.体格检查', '血压'): ['部位'],  # 都有，但是相当部分患者为空
    ('入院录.专科检查', '胸部听诊'): ['杂音部位', '杂音性质'],
    ('入院录.专科检查', '心脏听诊'): ['杂音部位', '杂音性质'],
    ('入院录.专科检查', '心尖搏动'): ['搏动点类型', '搏动点肋间数'],
    ('入院录.专科检查', '心脏浊音界'): ['浊音类型'],
    ('入院录.辅助检查'): ['检查项目', '检查结果'],
}
VAR_LIST = [  # 对应value为list（内部再无嵌套）或者为需要分隔的字符串
    ('入院录.既往史', '过敏史'),
    ('入院录.系统回顾', '神经系统'),
    ('入院录.系统回顾', '消化系统'),
    ('入院录.系统回顾', '循环系统'),
    ('入院录.系统回顾', '内分泌系统'),
    ('入院录.系统回顾', '造血系统'),
    ('入院录.系统回顾', '骨骼肌肉系统'),  # demo中无
    ('入院录.系统回顾', '呼吸系统'),
    ('入院录.系统回顾', '泌尿生殖系统'),
    ('入院录.其他信息', '个人史'),
    ('入院录.其他信息', '家族史'),
    ('入院录.体格检查', '其他症状'),
    ('入院录.专科检查', '其他症状'),
    ('入院录.疾病诊断', '疾病分类'),
    ('住院信息', '诊断信息', '入院诊断')
]


def overall_var_filter(dir_var_filter, sheet):
    """
    针对overall字段按照dir_var_filter过滤
    :param dir_var_filter: 需要的字段标签文件
    :param sheet: 对应sheet名字
    :return:
    """
    fields = pd.read_excel(dir_var_filter, sheet_name=sheet)
    fields = fields.loc[fields['是否需要'] == 1, ['属性名']]

    fields['目录'] = fields['属性名'].apply(lambda x: x.split('.'))
    fields = fields.set_index('属性名')  # 转化为字典
    fields = fields.to_dict()['目录']

    return fields


class PatientFields:
    """单患者/json字段"""
    def __init__(self, p_json, file_name):
        self.p_json = p_json
        self.f_name = file_name

    def fields_exist(self, fields_keep, patients_var):
        patients_var['fileName'].append(self.f_name)
        patients_var['身份证'].append(self.p_json['基本信息']['身份证'])
        for k in fields_keep:
            patients_var[k].append(
                PatientFields.field_exist(fields_keep[k], self.p_json))

    @staticmethod
    def field_exist(f_dir, dt):
        """
        针对overall的字段，递归检查是否存在
        :param f_dir: 字段在dt中一层层的key
        :param dt: json对应的dt
        """
        end_idx = 1 if f_dir[0] in dt else 2
        f = '.'.join(f_dir[0:end_idx])

        if isinstance(dt[f], list):
            return 0 if not dt[f] else 1
        elif isinstance(dt[f], (str, int, bool, float, type(None))):
            return 0 if dt[f] is None or dt[f] == "" else 1
        else:
            return PatientFields.field_exist(f_dir[end_idx:], dt[f])

    def fields_list_dict(self, items_cnt, var_dir, var_values):
        """
        var_dir对应的value为list，且内嵌dict，统计var_values各层级的患者频次和总频次
        患者频次：对应var_values一个患者无论出现几次都算一次
        总频次：一个患者对应var_values出现多次都统计
        :param items_cnt: 所有患者对应字段该项目的频数，以药嘱为例：(药名, 规格)对应的频次
        :var_dir: json文件中的key层层索引，直到其value为list，且嵌套dict
        :var_values: list中嵌套的dict中的field,多个即为层级关系，如检验套餐、检验项目
        """
        items_dt = self.p_json
        if isinstance(var_dir, str):  # key为str
            items_dt = items_dt[var_dir]
        else:
            for var in var_dir:  # key为tuple
                items_dt = items_dt[var]
                if not items_dt:
                    return items_dt

        p_items_cnt = collections.defaultdict(int)
        for item in items_dt:
            item_type = tuple([item[i] for i in var_values])
            if len(var_dir) == 2 and var_dir[1] == '血压':  # 每个患者都有该字段，但是很多为空
                if item['收缩压'] and item['舒张压']:
                    p_items_cnt[item_type] += 1
            else:
                p_items_cnt[item_type] += 1  # 统计该患者对应项目的总频次

        for item in p_items_cnt:
            if item in items_cnt:
                items_cnt[item][0] += 1
                items_cnt[item][1] += p_items_cnt[item]
            else:
                items_cnt[item].append(1)
                items_cnt[item].append(p_items_cnt[item])

        return items_cnt

    def fields_list_s(self, items_cnt, var_dir):
        """
        值为list（无嵌套数据结构）或者需要拆分的字符串，统计患者频次（选中才有）
        """
        items_dt = self.p_json
        for var in var_dir:
            items_dt = items_dt[var]
            if not items_dt:
                return items_cnt
        if var_dir[-1] == '入院诊断':
            items_dt = items_dt.split(';')

        for item in items_dt:
            items_cnt[item] += 1

        return items_cnt


class PatientsFieldsCount:
    """给定目录下的所有患者的字段统计"""
    def __init__(self):
        self.ans = {}

    def fields_count(self, dir_json, fields_keep):
        """
        遍历患者json文件抽取对应信息
        :param dir_json: 患者json文件夹
        :param fields_keep: 探查的字段
        :return:
        """
        files = os.listdir(dir_json)
        self.ans['patients'] = collections.defaultdict(list)

        for var in VAR_LIST_DICT:
            self.ans[var] = collections.defaultdict(list)
        for var in VAR_LIST:
            self.ans[var] = collections.defaultdict(int)

        for f in files:
            f_name = f.split('.')[0]
            logging.info(f"loading file: {f_name}")
            f_dir = os.path.join(dir_json, f)
            with open(f_dir, 'rb') as f_r:
                json_p = json.load(f_r)

            patient = PatientFields(json_p, f_name)
            patient.fields_exist(fields_keep, self.ans['patients'])

            for var in VAR_LIST_DICT:
                patient.fields_list_dict(self.ans[var], var, VAR_LIST_DICT[var])
            for var in VAR_LIST:
                patient.fields_list_s(self.ans[var], var)

        self.dictToDf()

    def dictToDf(self):
        """
        各频数统计结果均为dict，将其转化为df
        :param ans:
        :return:
        """
        for k in self.ans:
            dt = self.ans[k]
            if not dt:  # 为空的
                dt = None
            elif k in VAR_LIST_DICT:
                dt = [[*key, *value] for key, value in dt.items()]
                dt = pd.DataFrame(dt, columns=VAR_LIST_DICT[k] + ['患者频次',
                                                                  '总频次'])
                dt = dt.sort_values(by=['患者频次', '总频次'], ascending=False)
            elif k == 'patients':
                dt = pd.DataFrame(dt)
            else:
                dt = pd.DataFrame.from_dict(dt, orient='index').reset_index(
                    drop=False)
                col_first_name = '字段' if k == 'overall' else k[-1]
                dt.columns = [col_first_name, '患者频次']
                dt = dt.sort_values(by='患者频次', ascending=False)

            self.ans[k] = dt

        return self.ans

    def overall_fields_cnt(self):
        """针对patients表格统计各字段的频数"""
        patients_fields = self.ans['patients']
        df = patients_fields.iloc[:, 2:].sum(axis=0)
        df = df.sort_values(ascending=False)

        pid_cnt = patients_fields['身份证'].apply(
            lambda x: False if not x or x == '' else True)
        df = pd.concat([pd.Series(sum(pid_cnt), index=['身份证']), df])
        df = df.reset_index(drop=False)
        df.columns = ['字段', '患者频率']

        self.ans['overall'] = df

    def save_excel(self, dir_excel):
        with pd.ExcelWriter(dir_excel, mode='w') as w:
            for k in self.ans:
                if self.ans[k] is not None:
                    sheet = '.'.join(k) if isinstance(k, tuple) else k
                    self.ans[k].to_excel(w, sheet_name=sheet, index=False)


if __name__ == '__main__':
    logging.basicConfig(format='%(asctime)s: %(message)s', level=logging.INFO)
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    logging.info(f"start_time: {start_time}")

    dir_var_filter = '/Users/gxz/Desktop/PT/因果发现/data/demo/1_算法模型数据字典-20240711.xlsx'
    fields_keep = overall_var_filter(dir_var_filter, 'level_0')

    dir_jsons = '/Users/gxz/pt/complex/data/demo'
    ins = PatientsFieldsCount()
    ins.fields_count(dir_jsons, fields_keep)
    ins.overall_fields_cnt()

    dir_save = '/Users/gxz/Desktop/temp.xlsx'
    ins.save_excel(dir_save)

    end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    logging.info(f"end time: {end_time}")

