from tensordict import TensorDict
import collections
import torch
import os
import pickle
import pandas as pd
import numpy as np
import logging

from data_fillna import VALUE_REPLACE

COLS_MAP = {
    '药嘱-双鹤0.9%-氯化钠注射液': '双鹤氯化钠注射液',
    '药嘱-科伦5%-葡萄糖注射液': '科伦葡萄糖注射液'
}

# 按照干预是分类/连续进行循环
class DeciATE:
    def __init__(self, path_read, file_model, threshold):
        self.path_read = path_read
        self.sem = self.load_sem(file_model)
        with open(os.path.join(path_read, 'data_module.pkl'), 'rb') as f:
            self.data_module = pickle.load(f)
        self.adj = self.preprocess_adj(threshold)

    def load_sem(self, file_model):
        sem_module = torch.load(os.path.join(self.path_read, file_model))
        sem = sem_module()
        return sem

    def preprocess_adj(self, threshold):
        """
        从邻接矩阵中获取超过阈值的因果对，key为因，value为果
        Args:
            threshold:

        Returns:

        """
        adj_matrix = self.sem.mean.graph.detach().numpy()
        adj_idx = {}
        for i, row in enumerate(adj_matrix):
            col_idx = np.where(row > threshold)[0].tolist()
            if col_idx:
                adj_idx[i] = col_idx

        cols = list(self.data_module.dataset_train.keys())
        adj_dict = {}
        for k, vals in adj_idx.items():
            adj_dict[cols[k]] = [cols[v] for v in vals]

        return adj_dict

    def treatment_cate(self, treatment, outcome, treatment_levels, num_samples):
        """干预为分类变量"""
        ans = []

        levels = list(treatment_levels.keys())
        level_name = levels[0] if pd.isna(treatment_levels[levels[0]]) else treatment_levels[levels[0]]
        level_base_tensor = TensorDict(
            {treatment: torch.tensor([levels[0]])}, batch_size=tuple())
        base_samples = self.data_module.normalizer.inv(
            self.sem.mode.do(interventions=level_base_tensor).sample([num_samples]))[outcome]
        for i in levels[1:]:
            ans_i = [treatment, outcome]
            level_i_name = i if pd.isna(treatment_levels[i]) else treatment_levels[i]
            ans_i.append(f"{level_i_name} vs {level_name}")

            level_i_tensor = TensorDict(
                {treatment: torch.tensor([i])}, batch_size=tuple())
            i_samples = self.data_module.normalizer.inv(
                self.sem.mode.do(interventions=level_i_tensor).sample([num_samples]))[outcome]

            ate_mean = i_samples.mean(0) - base_samples.mean(0)
            ate_std = np.sqrt(
                (base_samples.var(0) + i_samples.var(0)) / num_samples)

            ans_i.append(ate_mean.numpy()[0])
            ans_i.append(ate_std.numpy()[0])
            ans.append(ans_i)

        return ans

    def treatment_conti(self, treatment, outcome, q1, q3, num_samples):
        """干预为连续变量"""
        q1_tensor = TensorDict({treatment: torch.tensor([q1])}, batch_size=tuple())
        q3_tensor = TensorDict({treatment: torch.tensor([q3])}, batch_size=tuple())

        q1_samples = self.data_module.normalizer.inv(
            self.sem.mode.do(interventions=q1_tensor).sample([num_samples]))[outcome]
        q3_samples = self.data_module.normalizer.inv(
            self.sem.mode.do(interventions=q3_tensor).sample([num_samples]))[outcome]

        ate_mean = (q3_samples.mean(0) - q1_samples.mean(0)) / (q3 - q1)
        ate_std = np.sqrt(
            (q1_samples.var(0) + q3_samples.var(0)) / num_samples) / (q3 - q1)

        return [treatment, outcome, None, ate_mean.numpy()[0], ate_std.numpy()[0]]

    @staticmethod
    def treatment_levels_map(levels, data_type_replace):
        """将干预因子从数字编码变回文字(返回根据数字编码排序后的有序字典)"""
        result = collections.OrderedDict()
        if pd.isna(data_type_replace):
            for l in set(levels):
                result[l] = None
            return result

        treatment_map = VALUE_REPLACE[data_type_replace]
        val_to_keys = collections.defaultdict(list)
        for key, value in treatment_map.items():
            val_to_keys[value].append(key)

        for val, keys in val_to_keys.items():
            result[val] = ','.join(keys)

        result_order = collections.OrderedDict(sorted(result.items(), key=lambda item: item[0]))
        return result_order

    @staticmethod
    def load_data_types(path_config):
        data_types = pd.read_excel(
            os.path.join(path_config, '字段缺失情况.xlsx'))
        data_types = data_types.query("数据类型 in ['分类', '连续']")
        data_types = data_types.set_index('字段')[['数据类型', '值替换']].apply(
            tuple, axis=1).to_dict()

        return data_types

    def run(self, path_config, num_samples=5000):
        data_types = self.load_data_types(path_config)
        result = []
        for key, vals in self.adj.items():
            if key in data_types:
                key_type = data_types[key][0]
            else:
                for k, v in COLS_MAP.items():
                    if v == key:
                        key_type = data_types[k][0]
                        break
            key_values = self.data_module.dataset_df[key].dropna()
            if key_type == '分类':
                key_values = self.treatment_levels_map(key_values, data_types[key][1])
                for val in vals:
                    logging.info(f"正在分析 {key} --> {val} ...")
                    val_ans = self.treatment_cate(
                        key, val, key_values, num_samples
                    )
                    result.extend(val_ans)
            elif key_type == '连续':
                q1 = float(key_values.quantile(q=0.25))
                q3 = float(key_values.quantile(q=0.75))
                for val in vals:
                    logging.info(f"正在分析 {key} --> {val} ...")
                    val_ans = self.treatment_conti(key, val, q1, q3, num_samples)
                    result.append(val_ans)

        result = pd.DataFrame(
            result, columns=['干预', '结果变量', '因子', 'ATE', 'ATE_std'])
        result.to_excel(os.path.join(path_save, 'ATE.xlsx'), index=False)


if __name__ == '__main__':
    logging.basicConfig(format='%(asctime)s: %(message)s', level=logging.INFO)

    path_read = '/Users/gxz/Desktop/PT/因果发现/result/demo'
    path_config = '/Users/gxz/Desktop/PT/因果发现/data/demo'
    path_save = '/Users/gxz/Desktop/PT/因果发现/result/demo'
    file_model = 'deci_spline.pt'

    ate_ins = DeciATE(path_read, file_model, 0.5)
    ate_ins.run(path_config, num_samples=100)

    logging.info("完成所有变量的ATE计算...")

