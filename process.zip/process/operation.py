import logging
import os.path
import pandas as pd


def split_and_extension(df):
    result = []
    for _, row in df.iterrows():
        oper_split = row['手术'].split('+')
        for o in oper_split:
            result.append({
                'json_name': row['json_name'],
                '手术': o
            })
    result = pd.DataFrame(result).drop_duplicates()
    return result


def operation_process(path_read):
    table_name = '住院信息.手术信息'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    df = df[['json_name', '手术']].dropna()
    df = split_and_extension(df)
    result = pd.pivot_table(
        df,
        index='json_name',
        columns='手术',
        aggfunc=lambda x: 1,  # 将值映射为 1
        fill_value=0  # 缺失值填充为 0
    ).reset_index()

    logging.info(f"{table_name} 表预处理完成……")
    return result


