import logging
import os.path

import pandas as pd

from patients import patients_process
from labs import labs_process
from order import order_process
from operation import operation_process
from symptom import symptom_process
from disease_history import disease_history_process
from operation_history import operation_history_process
from blood_pressure import bp_process
from heart_auscultaion import heart_aus_process
from diag_class import diag_class_process
from diag_admission import diag_admission_process
from drug_history import drug_history_process
from family_history import family_history_process


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

    read_path = '/Users/gxz/Desktop/PT/因果发现/data/raw'
    config_path = '/Users/gxz/Desktop/PT/因果发现/data'
    save_path = '/Users/gxz/Desktop/PT/因果发现/data/process'

    patients = patients_process(read_path)
    labs = labs_process(read_path, config_path)
    labs['时间'] = pd.to_datetime(labs['时间'])

    order = order_process(read_path, config_path)
    order['服药日期'] = pd.to_datetime(order['服药日期'])
    order = order.rename(columns={'服药日期': '时间'})

    operation = operation_process(read_path)
    symptom = symptom_process(read_path)
    disease_his = disease_history_process(read_path)
    operation_his = operation_history_process(read_path)
    bp = bp_process(read_path)
    heart_aus = heart_aus_process(read_path)
    diag_class = diag_class_process(read_path)
    diag_admission = diag_admission_process(read_path)
    drug_his = drug_history_process(read_path, config_path)
    family_his = family_history_process(read_path)

    outcome = pd.read_csv(os.path.join(read_path, 'outcome.csv'))

    result = (
        labs
        .merge(order, on=['json_name', '时间'], how='outer')
        .merge(patients, on=['json_name'], how='right')
        .merge(outcome, on=['json_name'], how='left')
        .merge(operation, on='json_name', how='left')
        .merge(symptom, on='json_name', how='left')
        .merge(disease_his, on='json_name', how='left')
        .merge(operation_his, on='json_name', how='left')
        .merge(bp, on='json_name', how='left')
        .merge(heart_aus, on='json_name', how='left')
        .merge(diag_class, on='json_name', how='left')
        .merge(diag_admission, on='json_name', how='left')
        .merge(drug_his, on='json_name', how='left')
        .merge(family_his, on='json_name', how='left')
    )
    result = result.sort_values(by=['json_name', '时间'])
    result.to_csv(os.path.join(save_path, 'integration.csv'), index=False)
    logging.info('All tables successful...')