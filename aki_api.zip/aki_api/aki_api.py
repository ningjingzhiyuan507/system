from flask import Flask, request
import pickle
import os

FIELDS_SORT = [
    'eGFR', 'PF', 'CPB', 'Surgery', 'cTnT', 'NLR', 'PLT', 'Age', 'BMI', 'Scr',
    'pRBCs']
FIELDS_VALUE = {
    'eGFR': [0, 200],
    'PF': [0, 1000],
    'CPB': [0, 2000],
    'Surgery': [0, 2000],
    'cTnT': [0, 50],
    'NLR': [0, 100],
    'PLT': [0, 2000],
    'Age': [0, 120],
    'BMI': [0, 50],
    'Scr': [0, 1000],
    'pRBCs': [0, 50]
}


def data_prepare(dt):
    lt = []
    for f in FIELDS_SORT:
        if f not in dt.keys():
            return {'FieldError': f'{f} 不是入参字段'}
        elif dt[f] is None:
            return {'ValueError': f'{f} 字段值为空'}
        elif not isinstance(dt[f], (int, float)):
            return {'TypeError': f'{f} 字段值必须为数字'}
        elif (dt[f] < FIELDS_VALUE[f][0]) or (dt[f] > FIELDS_VALUE[f][1]):
            return {'ValueError': f'{f} 字段值不在值域范围内'}
        else:
            lt.append(dt[f])

    return [lt]


app = Flask(__name__)


@app.route('/aki_predict', methods=['POST'])
def predict():
    dt = request.json
    data = data_prepare(dt)
    if isinstance(data, dict):
        return data

    probs = {}
    for i in range(1, 4):
        data_sc = scs_dt[f'day{i}_sc'].transform(data)
        probs[f'day{i}'] = models_dt[f'day{i}_model'].predict_proba(data_sc)[0][1]

    return probs


if __name__ == '__main__':
    dir_path = os.path.abspath('.')
    dir_path = os.path.join(dir_path, 'aki_api')

    scs_dt = {}
    models_dt = {}
    models = ['day1_rf.pkl', 'day2_lr.pkl', 'day3_gbdt.pkl']
    for i in range(1, 4):
        with open(os.path.join(dir_path, f'day{i}_scaler.pkl'), 'rb') as f:
            scs_dt[f'day{i}_sc'] = pickle.load(f)
        with open(os.path.join(dir_path, models[i-1]), 'rb') as f:
            models_dt[f'day{i}_model'] = pickle.load(f)

    app.run(host='0.0.0.0', port=8030, debug=True, threaded=True)
