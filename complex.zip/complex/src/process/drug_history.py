import logging
import os
import pandas as pd


def drug_history_process(path_read, path_config):
    table_name = '入院录.既往史.药物史'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    df = df[['json_name', '药物名称']].dropna()

    df_stand = pd.read_excel(
        os.path.join(path_config, '字段抽取-20250102.xlsx'),
        sheet_name='入院录.既往史.药物史')
    df_stand = df_stand.query("标准字段名 != '其它'")
    df = df.merge(df_stand[['药物名称', '标准字段名']], on='药物名称')

    results = pd.pivot_table(
        df[['json_name', '标准字段名']],
        index='json_name',
        columns='标准字段名',
        aggfunc=lambda x: 1,  # 将值映射为 1
        fill_value=0  # 缺失值填充为 0
    ).add_prefix('药物史_').reset_index()

    logging.info(f"{table_name} 表预处理完成……")
    return results


if __name__ == '__main__':
    path_read = '/Users/gxz/Desktop/PT/因果发现/data/raw'
    path_save = '/Users/gxz/Desktop/PT/因果发现/data/process'

    drug_history_process(path_read, path_save)



