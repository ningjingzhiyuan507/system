import logging

import pandas as pd
import numpy as np
import os


def patients_process(path_read):
    table_name = 'patients'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    cols_del = ['院区', '叩诊部位']
    df = df.drop(columns=cols_del)

    cols_replace = {
        '饮食': {'减少': '异常', '增加': '异常'},
        '大便': {'次数减少': '异常', '次数增加': '异常'},
        '小便': {'次数减少': '异常', '次数增加': '异常'},
        '民族': {'汉': '汉族'},
        '婚姻': {'离异': '离婚', '--': '其他'},
        '心功能分级': {
            '<数据异常>': 'I', '心功能I级': 'I', '心功能II级': 'II',
            '心功能III级': 'III', '心功能IV级': 'IV'
        },
        '子女健康状况': {'<数据异常>': None},
        '配偶健康状况': {'<数据异常>': None},
        '体温': {
            '37·': 37, '26.5': 36.5, '78': np.nan, '365': 36.5, '36.8/': 36.8,
            '100': np.nan, '11': np.nan, '3804': 38.04, '36..5': 36.5,
            '80': np.nan, '368': 36.8, '1': np.nan, ' 36.4': 36.4,
            '111': np.nan, '3.6.3': 36.3, '3.6.6': 36.6, '20': np.nan,
            '16': np.nan, '.7': np.nan, '62': np.nan, '38. 2': 38.2,
            '3608': 36.08, '66': np.nan, '14': np.nan, '36/6': 36.6, '36.': 36,
            '36..4': 36.4, '36.6`': 36.6, '36.5 ': 36.5, ' 36.6': 36.6
        },
        '心率': {
            '1': np.nan, '６０': 60, '36.2': np.nan,
            '82-102': 95, '36.4': np.nan, '36.6': np.nan,
            '7020': 70, '7818': 78, '37.2': np.nan,
            '82-94': 85, '36.8': np.nan
        },
        '籍贯': {'上海': '上海市'},
        '费用类型': {
            '居民医保': '医保', '国际部商保': '其他', '国际部自费': '自费',
            '工伤保险': '其他', '少儿共享': '其他'
        }
    }
    for c in cols_replace:
        df[c] = df[c].replace(cols_replace[c])

    df.loc[df['民族'] != '汉族', '民族'] = '其他'
    df.loc[df['胸部叩诊'] != '清音', '胸部叩诊'] = '异常'
    df.loc[df['胸部视诊'] != '正常', '胸部视诊'] = '异常'
    df['体温'] = df['体温'].astype(float)
    df['心率'] = df['心率'].astype(float)
    df.loc[~df['籍贯'].isin(['江苏省', '上海市', '安徽省', '浙江省']), '籍贯'] = '其他'

    logging.info(f"{table_name} 表预处理完成……")
    return df