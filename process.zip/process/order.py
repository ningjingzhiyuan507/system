import logging

import pandas as pd
import os


def order_date_extension(df):
    """根据开始时间和结束时间扩展"""
    result = []
    for _, row in df.iterrows():
        if row['周期'] == '带药':  # 带药：扩展为 7 天记录
            for i in range(7):
                result.append({
                    'json_name': row['json_name'],
                    '药物': row['标准字段名'],
                    '服药日期': row['开始时间'] + pd.Timedelta(days=i),
                    '每天剂量': row['每天剂量']
                })
        elif row['开始时间'] == row['结束时间']:
            result.append({
                'json_name': row['json_name'],
                '药物': row['标准字段名'],
                '服药日期': row['开始时间'],
                '每天剂量': row['每天剂量']
            })
        else:
            current_date = row['开始时间']
            while current_date < row['结束时间']:  # 不包含结束当天的
                result.append({
                    'json_name': row['json_name'],
                    '药物': row['标准字段名'],
                    '服药日期': current_date,
                    '每天剂量': row['每天剂量']
                })
                current_date += pd.Timedelta(days=1)
    result = pd.DataFrame(result).drop_duplicates(subset=['json_name', '药物', '服药日期'])
    return pd.DataFrame(result)


def order_process(path_read, path_config):
    table_name = '药嘱'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    order_stand = pd.read_excel(
        os.path.join(path_config, '字段抽取-20250102.xlsx'), sheet_name='药嘱')
    order_stand = order_stand.dropna(subset=['标准字段名']).drop_duplicates(subset='药名')
    df = df.dropna(subset=['周期', '药名', '开始时间', '结束时间'])
    df = df.merge(order_stand[['药名', '标准字段名']], on='药名')

    # 规格单位转换
    drugs_norm = {
        '肝素钙': {'1.00万U/支': '10,000.00U/支'},
        '乙酰半胱氨酸': {'600.00mg/片': '0.60g/片'},
        '盐酸万古霉素': {'0.50g/支': '50.00万U/支'},
        '盐酸胺碘酮': {'150.00mg/支': '0.15g/支'},
        '米力农': {'5.00mg/支': '5.00ml/支'},
        '蔗糖铁': {'0.10g/支': '100.00mg/支'},
        '阿司匹林': {'0.10g/片': '100mg/片'},
        '左氧氟沙星': {'24.40mg/支': '0.0244mg/支'},
        '二甲双胍': {
            '850.00mg/片': '0.85g/片', '2.50mg/粒': '0.0025g/粒',
            '500.00mg/片': '0.5g/片'},
        '盐酸右美托咪定': {'200.00ug/瓶': '0.20mg/瓶'},
    }
    for key, values in drugs_norm.items():
        for old, new in values.items():
            df.loc[(df['标准字段名'] == key) & (df['规格'] == old), '规格'] = new

    # 数据抽取和转化
    cols_astype = ['规格', '数量']
    for c in cols_astype:
        df[c] = (
            df[c]
            .str.extract(r'([\d,\.]+)')
            .replace(',', '', regex=True)
            .astype(float)
        )

    df.loc[df['规格'] == 0, '规格'] = 1
    df = df.loc[df['数量'] != 0, :]  # 剔除数量为0的

    # 频率转化
    drug_freq = {
        '24h': 1,
        '120h': 1 / 5,
        '48h': 1 / 2,
        'bid': 2,
        'biw': 2 / 7,
        'prn': 1,
        'q12h': 2,
        'q2h': 12,
        'q4h': 6,
        'q6h': 4,
        'q72h': 1 / 3,
        'q8h': 3,
        'qd': 1,
        'qh': 24,
        'qid': 4,
        'qm': 1 / 30,
        'qn': 1,
        'qod': 1 / 2,
        'qw': 1 / 7,
        'q2w': 2 / 7,
        'st': 1,
        'tid': 3,
        'tiw': 3 / 7
    }
    df['频率'] = df['频率'].replace(drug_freq).astype(float)
    df['频率'] = df['频率'].fillna(value=1)

    # 每天剂量
    df['每天剂量'] = df['频率'] * df['规格'] * df['数量']
    # df.loc[df['标准字段名'] == '输血', '输血'] = 1

    # 扩展天数
    df['开始时间'] = pd.to_datetime(df['开始时间'])
    df['结束时间'] = pd.to_datetime(df['结束时间'])
    df = order_date_extension(df)
    df = df.pivot(index=['json_name', '服药日期'], columns='药物', values='每天剂量').reset_index()
    df = df.fillna(0)

    logging.info(f"{table_name} 表预处理完成……")
    return df


if __name__ == '__main__':
    path_read = '/Users/gxz/Desktop/PT/因果发现/data/raw'
    path_config = '/Users/gxz/Desktop/PT/因果发现/data'
    path_save = '/Users/gxz/Desktop/PT/因果发现/data/process'

    order_process(path_read, path_config, path_save)