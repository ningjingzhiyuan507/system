import logging
import os.path
import pandas as pd


def diag_class_process(path_read):
    table_name = '入院录.疾病诊断.疾病分类'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    df = df.dropna().query('value != "10"')
    results = []
    for _, row in df.iterrows():
        diag_split = row['value'].split(',')
        for d in diag_split:
            results.append({
                'json_name': row['json_name'],
                '诊断分类': d
            })
    results = pd.DataFrame(results)
    results = pd.pivot_table(
        results,
        index='json_name',
        columns='诊断分类',
        aggfunc=lambda x: 1,  # 将值映射为 1
        fill_value=0  # 缺失值填充为 0
    ).add_prefix('诊断分类_').reset_index()

    logging.info(f"{table_name} 表预处理完成……")
    return results


