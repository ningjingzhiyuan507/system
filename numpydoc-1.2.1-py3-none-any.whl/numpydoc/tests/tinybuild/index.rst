numpydoc_test_module
====================

.. automodule:: numpydoc_test_module
   :no-members:
   :no-inherited-members:
   :no-special-members:
