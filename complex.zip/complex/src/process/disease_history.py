import logging
import os
import pandas as pd


def disease_history_process(path_read):
    table_name = '入院录.既往史.疾病史'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    df = df[['json_name', '疾病名', '持续时间', '持续时间单位']].dropna()
    df = df.query("持续时间单位 != '<数据异常>'")
    diseases = ['高血压', '糖尿病', '冠心病', '心律失常', '脑血管病', '肾功能不全']
    time_unit = {
        '年': 365,
        '月': 30,
        '日': 1
    }
    results = []
    for _, row in df.iterrows():
        for d in diseases:
            if d in row['疾病名']:
                results.append({
                    'json_name': row['json_name'],
                    '疾病名': d,
                    '持续时间': row['持续时间'] * time_unit[row['持续时间单位']]
                })
    results = (
        pd.DataFrame(results)
        .drop_duplicates(subset=['json_name', '疾病名'])
        .pivot(index='json_name', columns='疾病名', values='持续时间')
        .add_prefix('疾病史_')
        .reset_index()
        .fillna(0)
    )

    logging.info(f'{table_name} 表预处理完成……')
    return results


if __name__ == '__main__':
    path_read = '/Users/gxz/Desktop/PT/因果发现/data/raw'
    path_save = '/Users/gxz/Desktop/PT/因果发现/data/process'

    disease_history_process(path_read, path_save)