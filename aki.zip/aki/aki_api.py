from flask import Flask, request
import pickle
import os

# {"eGFR": 80.11,"PF": 334.0,"CPB": 141.63333,"Surgery": 322,"cTnT": 0.006,"NLR": 1.038461,"PLT": 292,"Age": 65,"BMI": 21.048048,"Scr": 87.0,"pRBCs": 4.0}


def data_prepare(dt):
    features_sort = [
        'eGFR', 'PF', 'CPB', 'Surgery', 'cTnT', 'NLR', 'PLT', 'Age', 'BMI', 'Scr', 'pRBCs']

    lt = []
    for k in features_sort:
        if dt[k] is not None:
            lt.append(dt[k])
        else:
            return f'{k}字段值为空'

    return [lt]


app = Flask(__name__)


@app.route('/aki_predict', methods=['POST'])
def predict():
    dt = request.json
    data = data_prepare(dt)
    if isinstance(data, str):
        return {'ValueError': data}

    probs = {}
    for i in range(1, 4):
        data_sc = scs_dt[f'day{i}_sc'].transform(data)
        probs[f'day{i}'] = models_dt[f'day{i}_model'].predict_proba(data_sc)[0][1]

    return probs


if __name__ == '__main__':
    dir_path = os.path.abspath('.')
    dir_path = os.path.join(dir_path, 'aki_api')

    scs_dt = {}
    models_dt = {}
    models = ['day1_rf.pkl', 'day2_lr.pkl', 'day3_gbdt.pkl']
    for i in range(1, 4):
        with open(os.path.join(dir_path, f'day{i}_scaler.pkl'), 'rb') as f:
            scs_dt[f'day{i}_sc'] = pickle.load(f)
        with open(os.path.join(dir_path, models[i-1]), 'rb') as f:
            models_dt[f'day{i}_model'] = pickle.load(f)

    app.run(debug=True, host='127.0.0.1', port=8030)  # 10.15.17.11
