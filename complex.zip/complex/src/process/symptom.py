import logging
import os
import pandas as pd


def symptom_process(path_read):
    table_name = '入院录.基本信息.症状'
    df = pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
    df = df[['json_name', '症状名称', '性质', '出现时间', '出现时间单位']].dropna()
    df = df.query("症状名称 != '<数据异常>'")
    df.loc[df['性质'].isin(['不规则热', '间歇热', '稽留热', '弛张热', '回归热']), '性质'] = '发热'
    df.loc[df['症状名称'].isin(['夜间阵发性呼吸困难', '端坐呼吸']), '症状名称'] = '气促'
    df.loc[df['症状名称'].isin(['胸前区压迫感', '端坐呼吸']), '症状名称'] = '胸闷'
    df.loc[df['出现时间'] > 1000, '出现时间'] = 2024 - df.loc[df['出现时间'] > 1000, '出现时间']

    time_unit = {
        '年': 365,
        '月': 30,
        '天': 1,
        '周': 7,
        '小时': 1/24
    }
    df['出现时间'] = df.apply(lambda row: row['出现时间'] * time_unit[row['出现时间单位']], axis=1)
    df['症状-性质'] = df['症状名称'] + '-' + df['性质']
    df = df.drop_duplicates(subset=['json_name', '症状-性质'])
    df = df.pivot(index='json_name', columns='症状-性质', values='出现时间').reset_index()
    df = df.fillna(0)

    logging.info(f"{table_name} 表预处理完成……")
    return df


if __name__ == '__main__':
    path_read = '/Users/gxz/Desktop/PT/因果发现/data/raw'
    path_save = '/Users/gxz/Desktop/PT/因果发现/data/process'

    symptom_process(path_read, path_save)



