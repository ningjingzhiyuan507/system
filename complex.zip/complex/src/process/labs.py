import logging

import pandas as pd
import re
import os


def get_labs_nums(df, col_name):
    """
    对指定的package-item进行获取数字处理，剔除文字和<>
    Args:
        df: labs
        col_name: 套餐-项目

    Returns:

    """
    df[col_name] = df[col_name].apply(
        lambda text: float(re.search(r"-?\d*\.?\d+", str(text)).group(0)) if pd.notna(text) and re.search(r"-?\d*\.?\d+", str(text)) else None
    )
    return df


def unified_labs_unit(df, package_item, ratio):
    """
    对指定的package-item-unit进行单位转化
    Args:
        df: labs
        package_item: (package, item, unit_old, unit_new)
        ratio: 转成新单位的汇率
    Returns:

    """
    condition = (df['项目'] == package_item[0]) & (df['单位'] == package_item[1])
    df.loc[condition, '结果'] = df.loc[condition, '结果'].astype(float)
    df.loc[condition, '结果'] = df.loc[condition, '结果'] * ratio
    df.loc[condition, '单位'] = package_item[2]
    return df


def merge_labs_cates(df, col_name, reclass_dict, main_cate=None, other_cate=None):
    """
    对指定套餐-项目的值进行重分类
    Args:
        df: labs
        col_name: 套餐-项目
        reclass_dict: {标准名称: [属于对应标准名称的结果值]}
        main_cate: 主要类别，也就是非main_cate都归为other_cate
        other_cate:

    Returns:

    """
    if len(reclass_dict) > 0:
        for stand, value in reclass_dict.items():
            df.loc[df[col_name].isin(value), col_name] = stand
    if main_cate:
        df.loc[(pd.notna(df[col_name])) & (df[col_name] != main_cate), col_name] = other_cate

    return df


def labs_items_stand(df, items_stand_dt):
    """
    使用详细类型-项目-单位进行项目标准化
    Args:
        df:
        items_stand_dt:

    Returns:

    """
    for key, value in items_stand_dt.items():
        if isinstance(value[0], str):
            df.loc[df['项目'].isin(value), '项目'] = key
        else:
            for v in value:
                df.loc[(df['项目'] == v[0]) & (df['单位'] == v[1]), '项目'] = key

    return df


def patient_fill(group):
    """患者维度的字段填充"""
    cols = [
        '基因检测-ABCB1/rs1045642', '基因检测-CYP2C19', '基因检测-CYP2C19-636',
        '基因检测-CYP2C19-681', '基因检测-MTHFR/rs1801133',
        '血型鉴定-ABO血型', '血型鉴定-Rh(D)因子',
    ]
    for c in cols:
        if any(pd.notna(group[c])):
            group[c] = group[c].dropna().iloc[0]

    return group


ITEMS_STAND = {
    '微生物-涂片-找真菌': [
        '微生物-涂片-找见真菌孢子', '微生物-涂片-找见真菌菌丝',
        '微生物-涂片-找见真菌菌丝+孢子'
    ],
    '微生物-涂片-找细菌': [
        '微生物-涂片-找见革兰阳性杆菌', '微生物-涂片-找见革兰阳性球菌',
        '微生物-涂片-找见革兰阴性杆菌', '微生物-涂片-找见革兰阴性球菌'
        '微生物-涂片-找隐球菌'
    ],
    '电解质-钙离子': [
        '电解质-CA++', '电解质-离子钙'
    ],
    '血常规-白细胞计数': [
        ('血常规-白细胞', '/mm3'), ('血常规-白细胞', 'X10^9/L')
    ],
    '血常规-红细胞计数': [
        ('血常规-红细胞', '/mm3'), ('血常规-红细胞', 'X10^12/L')
    ],
    '血气分析-BE(B)': ['血气分析-BE'],
    '血气分析-葡萄糖': ['血气分析-葡萄糖（空腹）'],
    '血气分析-阴离子隙': ['血气分析-阴离子间隙']
}

LABS_UNIT_STAND = {
    ('血常规-淋巴细胞数', 'cells/uL', 'X10^9/L'): 1000,
    ('血常规-白细胞计数', '/mm3', 'X10^9/L'): 0.001,
    ('血常规-白细胞计数', '/uL', 'X10^9/L'): 0.001,
    ('血常规-白细胞计数', '/ul', 'X10^9/L'): 0.001,
    ('血常规-红细胞计数', '/mm3', 'X10^12/L'): 0.000001,
    ('血常规-红细胞计数', '/uL', 'X10^12/L'): 0.000001,
    ('血常规-红细胞计数', '/ul', 'X10^12/L'): 0.000001,
    ('血气分析-BILI', 'umol/L', 'mg/dl'): 0.0585,
    ('血气分析-葡萄糖', 'mg/dl', 'mmol/L'): 0.0555,
    ('随机尿检测-尿液尿酸测定', 'umol/L', 'mmol/L'): 1000,
}


VALUE_RECLASS = {
    ('其他-血滴图诊断', '正常', '异常'): {'正常': ['基本正常']},
    ('基因检测-ABCB1/rs1045642', None, None): {
        'CT': ['杂合突变CT'],
        'CC': ['野生型CC'],
        'TT': ['纯合突变TT']
    },
    ('基因检测-MTHFR/rs1801133', None, None): {
        'CT': ['杂合突变CT'],
        'CC': ['野生型CC'],
        'TT': ['纯合突变TT']
    },
    ('尿液检查-小圆上皮细胞', '阴性', '阳性'): {
        '阴性': ['0.7', '0.2', '0.5', '1.0', '0.0', '0.4' '0.8', '0.1']
    },
    ('尿液检查-尿胆原', '正常', '异常'): {},
    ('尿液检查-尿隐血', '阴性', '阳性'): {},
    ('尿液检查-白细胞酯酶', '阴性', '阳性'): {},
    ('尿液检查-白细胞镜检', '阴性', '阳性'): {},
    ('尿液检查-红细胞信息', '阴性', '阳性'): {},
    ('尿液检查-红细胞镜检', '阴性', '阳性'): {},
    ('尿液检查-结晶检查', '阴性', '阳性'): {'阴性': ['0.0']},
    ('尿液检查-胆红素', '阴性', '阳性'): {},
    ('尿液检查-蛋白', '阴性', '阳性'): {},
    ('尿液检查-透明度', None, None): {
        '浊': ['微浊', '浊', '混浊', '混浊粘'],
        '清': ['透明']
    },
    ('尿液检查-透明管型', '未找到', '找到'): {},
    ('尿液检查-酮体', '阴性', '阳性'): {},
    ('尿液检查-酵母菌镜检', None, None): {'找到': ['偶见']},
    ('尿液检查-颗粒管型', '未找到', '找到'): {},
    ('微生物-涂片-找真菌', '阴性', '阳性'): {},
    ('微生物-涂片-找细菌', '阴性', '阳性'): {},
    ('微生物-草绿色链球菌', None, None): {'阳性': ['1+', '2+', '3+', '4+', '少量']},
    ('微生物-鲍曼不动杆菌', None, None): {'阳性': ['3+', '阳性', '2+', '4+', '200.000', '1+']},
    ('抗体-抗体筛选', None, None): {'-': ['0.000']},
    ('抗体-梅毒特异性抗体', None, None): {'呈阳性反应': ['*****.***']},
    ('粪便检查-吞噬细胞', '阴性', '阳性'): {},
    ('粪便检查-性状', '软', '异常'): {},
    ('粪便检查-粘液', '阴性', '阳性'): {},
    ('粪便检查-粪隐血', '阴性', '阳性'): {},
    ('粪便检查-脂肪滴', None, None): {'未找到': ['未见'], '找到': ['见到']},
    ('粪便检查-血液', '阴性', '阳性'): {},
    ('粪便检查-霉菌', '未找到', '找到'): {},
    ('粪便检查-颜色', '正常', '异常'): {'正常': ['黄色', '褐色', '黄褐色']},
    ('药物敏感性-亚胺培南', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介'], 'O': ['* 其他']},
    ('药物敏感性-哌拉西林/他唑巴坦', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介'], 'O': ['QT']},
    ('药物敏感性-头孢他啶', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介'], 'O': ['* 其他', 'NS 非敏感']},
    ('药物敏感性-头孢吡肟', None, None): {'R': ['R 耐药'], 'S': ['S 敏感', 'SDD', 'SDD 剂量依赖敏感'], 'I': ['I 中介'], 'O': ['QT', '* 其他']},
    ('药物敏感性-头孢哌酮/舒巴坦', None, None): {'R': ['R 耐药'], 'S': ['S 敏感', 'SDD'], 'I': ['I 中介'], 'O': ['QT']},
    ('药物敏感性-妥布霉素', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介']},
    ('药物敏感性-左氧氟沙星', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介']},
    ('药物敏感性-替加环素', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介']},
    ('药物敏感性-氨苄西林/舒巴坦', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介']},
    ('药物敏感性-环丙沙星', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介'], 'O': ['NS 非敏感', '* 其他']},
    ('药物敏感性-甲氧苄啶/磺胺异恶唑', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介'], 'O': ['* 其他']},
    ('药物敏感性-米诺环素', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介']},
    ('药物敏感性-美罗培南', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介'], 'O': ['* 其他']},
    ('药物敏感性-阿米卡星', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介']},
    ('药物敏感性-黏菌素', None, None): {'R': ['R 耐药'], 'S': ['S 敏感'], 'I': ['I 中介'], 'O': ['X']},
    ('血常规-白细胞', '阴性', '阳性'): {'阴性': ['0-1', '1-3', '1-2', '1']},
    ('血常规-红细胞', '阴性', '阳性'): {'阴性': ['0-1', '0-2', '1-2']},
}


def labs_process(path_read, path_config):
    table_name = '化验结果'
    df = (
        pd.read_csv(os.path.join(path_read, f'{table_name}.csv'))
        .dropna(subset=['json_name', '详细类型', '项目', '时间', '结果'])
        .query("详细类型 != '<暂无分类>'")
    )

    # 项目标准化
    df['项目'] = df['详细类型'] + '-' + df['项目']
    df = labs_items_stand(df, ITEMS_STAND)

    # 筛选频数大于1000的
    df_sub = (
        df
        .groupby("项目")
        .size()
        .reset_index(name="频数")
        .query("频数 >= 1000")
        .merge(df, on="项目", how="inner")
    )

    # 单位标准化
    for item in LABS_UNIT_STAND:
        df_sub = unified_labs_unit(df_sub, item, LABS_UNIT_STAND[item])

    # long to wide
    df_sub = df_sub[['json_name', '项目', '时间', '结果']].drop_duplicates(
        subset=['json_name', '项目', '时间'])
    df_sub['时间'] = pd.to_datetime(df_sub['时间'])
    df_sub = df_sub.pivot(index=['json_name', '时间'], columns='项目', values='结果').reset_index()
    df_sub = df_sub.groupby('json_name', group_keys=True).apply(patient_fill).reset_index(drop=True)

    # 重新分类
    for item in VALUE_RECLASS:
        df_sub = merge_labs_cates(
            df_sub, item[0], VALUE_RECLASS[item], item[1], item[2])

    # 删除无用变量
    values_stand = pd.read_excel(os.path.join(path_config, 'labs_值标准化.xlsx'))
    cols_del = values_stand.loc[values_stand['处理类型'] == 2, 'Column'].tolist()
    df_sub = df_sub.drop(columns=cols_del)
    # 处理数字型
    items_num = values_stand.loc[values_stand['处理类型'] == 1, :]
    for _, row in items_num.iterrows():
        df_sub = get_labs_nums(df_sub, row['Column'])

    logging.info(f"{table_name} 表预处理完成……")
    return df_sub


if __name__ == '__main__':
    path_read = '/Users/gxz/Desktop/PT/因果发现/data/raw'
    path_config = '/Users/gxz/Desktop/PT/因果发现/data'
    path_save = '/Users/gxz/Desktop/PT/因果发现/data/process'

    labs_process(path_read, path_config, path_save)

